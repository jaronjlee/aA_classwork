require 'test_helper'

class GardenTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
